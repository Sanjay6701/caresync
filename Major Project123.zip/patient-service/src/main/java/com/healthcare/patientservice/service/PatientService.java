package com.healthcare.patientservice.service;

import com.healthcare.patientservice.entity.Patient;
import com.healthcare.patientservice.repository.PatientRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PatientService {

    private final PatientRepository repository;

    public PatientService(PatientRepository repository) {
        this.repository = repository;
    }

    public Patient createOrGet(Patient p) {
        return repository.findByContact(p.getContact())
                .orElseGet(() -> repository.save(p));
    }

    public Patient getById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Patient not found"));
    }

    public List<Patient> getAll() {
        return repository.findAll();
    }
}