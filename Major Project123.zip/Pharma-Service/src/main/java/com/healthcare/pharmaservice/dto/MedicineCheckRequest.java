package com.healthcare.pharmaservice.dto;

public class MedicineCheckRequest {

    private String medicines;
    // Example: "Paracetamol:2,Cetrizine:1"

    public String getMedicines() {
        return medicines;
    }

    public void setMedicines(String medicines) {
        this.medicines = medicines;
    }
}
