package com.healthcare.pharmaservice.controller;

import com.healthcare.pharmaservice.dto.MedicineCheckRequest;
import com.healthcare.pharmaservice.service.PharmaService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/pharma")
public class PharmaController {

    private final PharmaService service;

    public PharmaController(PharmaService service) {
        this.service = service;
    }
    
    @GetMapping("/hello")
    public String hello()
    {
    	return "hello";
    }
    
    // ✅ Uses RequestBody instead of Params
    @PostMapping("/check")
    public Map<String, Object> checkMedicineAvailability(
            @RequestBody MedicineCheckRequest request) {

        return service.checkAvailability(request.getMedicines());
    }
}
