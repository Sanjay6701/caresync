package com.healthcare.pharmaservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class PharmaServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(PharmaServiceApplication.class, args);
    }
}