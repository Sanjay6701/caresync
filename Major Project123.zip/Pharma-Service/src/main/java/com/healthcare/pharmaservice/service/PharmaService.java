package com.healthcare.pharmaservice.service;

import com.healthcare.pharmaservice.entity.Medicine;
import com.healthcare.pharmaservice.repository.MedicineRepository;
import org.springframework.stereotype.Service;
import java.util.Map;

@Service
public class PharmaService {

    private final MedicineRepository repository;

    public PharmaService(MedicineRepository repository) {
        this.repository = repository;
    }

    public Map<String, Object> checkAvailability(String medicineList) {

        String[] items = medicineList.split(",");
        double totalCost = 0;

        for (String item : items) {

            String[] part = item.split(":");

            if (part.length != 2) {
                throw new RuntimeException("Invalid medicine format: " + item);
            }

            String medName = part[0].trim();
            int qty = Integer.parseInt(part[1].trim());

            Medicine med = repository.findByNameIgnoreCase(medName)
                    .orElseThrow(() ->
                            new RuntimeException("Medicine not found in DB: " + medName));

            if (med.getStockQuantity() < qty) {
                return Map.of(
                    "status", "OUT_OF_STOCK",
                    "medicine", medName
                );
            }

            totalCost += qty * med.getPricePerUnit();
        }

        return Map.of(
            "status", "AVAILABLE",
            "totalCost", totalCost
        );
    }}