package com.healthcare.authservice.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.healthcare.authservice.dto.ApiResponse;
import com.healthcare.authservice.entity.Doctor;
import com.healthcare.authservice.service.DoctorService;

@RestController
@RequestMapping("/api/doctors")
public class DoctorController {

    private final DoctorService doctorService;

    public DoctorController(DoctorService doctorService) {
        this.doctorService = doctorService;
    }

    @PostMapping
    public ApiResponse<Doctor> createDoctor(
            @RequestBody Doctor doctor) {

        return new ApiResponse<>(
                true,
                "Doctor created successfully",
                doctorService.createDoctor(doctor),
                201
        );
    }

    @GetMapping
    public ApiResponse<List<Doctor>> getAllDoctors() {
        return new ApiResponse<>(
                true,
                "Doctors fetched successfully",
                doctorService.getAllDoctors(),
                200
        );
    }

    @GetMapping("/{id}")
    public ApiResponse<Doctor> getDoctorById(@PathVariable Long id) {
        return new ApiResponse<>(
                true,
                "Doctor fetched successfully",
                doctorService.getDoctorById(id),
                200
        );
    }

    @PutMapping("/{id}")
    public ApiResponse<Doctor> updateDoctor(
            @PathVariable Long id,
            @RequestBody Doctor doctor) {

        return new ApiResponse<>(
                true,
                "Doctor updated successfully",
                doctorService.updateDoctor(id, doctor),
                200
        );
    }

    @DeleteMapping("/{id}")
    public ApiResponse<Object> deleteDoctor(@PathVariable Long id) {

        doctorService.deleteDoctor(id);

        return new ApiResponse<>(
                true,
                "Doctor deleted successfully",
                null,
                200
        );
    }
}
