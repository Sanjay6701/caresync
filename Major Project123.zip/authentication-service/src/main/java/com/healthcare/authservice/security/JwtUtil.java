package com.healthcare.authservice.security;

import java.security.Key;
import java.util.Date;

import org.springframework.stereotype.Component;

import com.healthcare.authservice.entity.Doctor;
import com.healthcare.authservice.entity.Patient;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtUtil {

    private final String SECRET =
            "HealthcareAuthServiceJwtSecretKey2026";

    private final long EXPIRATION = 1000 * 60 * 60; // 1 hour

    private Key getSigningKey() {
        return Keys.hmacShaKeyFor(SECRET.getBytes());
    }

    // ✅ Patient token
    public String generateTokenForPatient(Patient patient) {
        return Jwts.builder()
                .setSubject(patient.getEmail())
                .claim("role", patient.getRole())
                .claim("pid", patient.getPid())
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION))
                .signWith(getSigningKey(), SignatureAlgorithm.HS256)
                .compact();
    }

    // ✅ Doctor token
    public String generateTokenForDoctor(Doctor doctor) {
        return Jwts.builder()
                .setSubject(doctor.getEmail())
                .claim("role", doctor.getRole())
                .claim("did", doctor.getDid())
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION))
                .signWith(getSigningKey(), SignatureAlgorithm.HS256)
                .compact();
    }

    // ✅ Admin token (same as doctor, role = ADMIN)
    public String generateTokenForAdmin(Doctor admin) {
        return Jwts.builder()
                .setSubject(admin.getEmail())
                .claim("role", "ADMIN")
                .claim("did", admin.getDid())
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION))
                .signWith(getSigningKey(), SignatureAlgorithm.HS256)
                .compact();
    }

    public String extractEmail(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(getSigningKey())
                .build()
                .parseClaimsJws(token)
                .getBody()
                .getSubject();
    }
}