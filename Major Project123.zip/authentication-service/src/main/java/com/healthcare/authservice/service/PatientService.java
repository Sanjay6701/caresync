package com.healthcare.authservice.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.healthcare.authservice.entity.Patient;
import com.healthcare.authservice.repository.PatientRepository;

@Service
public class PatientService {

    private final PatientRepository patientRepository;

    public PatientService(PatientRepository patientRepository) {
        this.patientRepository = patientRepository;
    }

    public Patient createPatient(Patient patient) {

        if (patientRepository.existsByEmail(patient.getEmail())) {
            throw new RuntimeException(
                    "Patient already exists with email: " + patient.getEmail());
        }

        return patientRepository.save(patient);
    }

    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    public Patient getPatientById(Long id) {
        return patientRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Patient not found with id: " + id));
    }

    public Patient updatePatient(Long id, Patient patient) {

        Patient existing = patientRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Patient not found with id: " + id));

        if (!existing.getEmail().equals(patient.getEmail())
                && patientRepository.existsByEmail(patient.getEmail())) {
            throw new RuntimeException(
                    "Email already in use: " + patient.getEmail());
        }

        existing.setName(patient.getName());
        existing.setEmail(patient.getEmail());
        existing.setGender(patient.getGender());
        existing.setAge(patient.getAge());

        return patientRepository.save(existing);
    }

    public void deletePatient(Long id) {

        Patient existing = patientRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Patient not found with id: " + id));

        patientRepository.delete(existing);
    }
}