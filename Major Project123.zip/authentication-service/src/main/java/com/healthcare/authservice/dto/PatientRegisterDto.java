package com.healthcare.authservice.dto;

import lombok.Data;

@Data
public class PatientRegisterDto {

    private String name;
    private String email;
    private String password;
    private String gender;
    private int age;
}