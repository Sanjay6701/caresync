package com.healthcare.authservice.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.healthcare.authservice.entity.Doctor;
import com.healthcare.authservice.repository.DoctorRepository;

@Configuration
public class DataInitializer implements CommandLineRunner {

    private final DoctorRepository doctorRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(DoctorRepository doctorRepository,
                           PasswordEncoder passwordEncoder) {
        this.doctorRepository = doctorRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {

        if (!doctorRepository.findByEmail("admin@healthcare.com").isPresent()) {

            Doctor admin = new Doctor();
            admin.setName("Admin");
            admin.setEmail("admin@healthcare.com");
            admin.setPassword(passwordEncoder.encode("admin123"));
            admin.setSpecialization("SYSTEM_ADMIN");
            admin.setRate(0);
            admin.setRole("ADMIN");

            doctorRepository.save(admin);

            System.out.println("✅ Admin created successfully!");
        }
    }
}