package com.healthcare.authservice.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.healthcare.authservice.entity.Doctor;
import com.healthcare.authservice.repository.DoctorRepository;

@Service
public class DoctorService {

    private final DoctorRepository doctorRepository;

    public DoctorService(DoctorRepository doctorRepository) {
        this.doctorRepository = doctorRepository;
    }

    public Doctor createDoctor(Doctor doctor) {

        if (doctorRepository.existsByEmail(doctor.getEmail())) {
            throw new RuntimeException(
                    "Doctor already exists with email: " + doctor.getEmail());
        }

        return doctorRepository.save(doctor);
    }

    public List<Doctor> getAllDoctors() {
        return doctorRepository.findAll();
    }

    public Doctor getDoctorById(Long id) {
        return doctorRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Doctor not found with id: " + id));
    }

    public Doctor updateDoctor(Long id, Doctor doctor) {

        Doctor existing = doctorRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Doctor not found with id: " + id));

        if (!existing.getEmail().equals(doctor.getEmail())
                && doctorRepository.existsByEmail(doctor.getEmail())) {
            throw new RuntimeException(
                    "Email already in use: " + doctor.getEmail());
        }

        existing.setName(doctor.getName());
        existing.setEmail(doctor.getEmail());
        existing.setSpecialization(doctor.getSpecialization());
        existing.setRate(doctor.getRate());

        return doctorRepository.save(existing);
    }

    public void deleteDoctor(Long id) {

        Doctor existing = doctorRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Doctor not found with id: " + id));

        doctorRepository.delete(existing);
    }
}
