package com.healthcare.authservice.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.healthcare.authservice.entity.Doctor;


@Repository
public interface DoctorRepository  extends JpaRepository<Doctor, Long>{
	Optional<Doctor> findByEmail(String email);
	
	boolean existsByEmail(String email);

}
