package com.healthcare.authservice.security;

import java.util.Collections;

import org.springframework.security.core.userdetails.*;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;

import com.healthcare.authservice.entity.Patient;
import com.healthcare.authservice.entity.Doctor;
import com.healthcare.authservice.repository.PatientRepository;
import com.healthcare.authservice.repository.DoctorRepository;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;

    public CustomUserDetailsService(PatientRepository patientRepository,
                                    DoctorRepository doctorRepository) {
        this.patientRepository = patientRepository;
        this.doctorRepository = doctorRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String email)
            throws UsernameNotFoundException {

        Patient patient = patientRepository.findByEmail(email).orElse(null);
        if (patient != null) {
            return new org.springframework.security.core.userdetails.User(
                    patient.getEmail(),
                    patient.getPassword(),
                    Collections.singletonList(
                            new SimpleGrantedAuthority(
                                    "ROLE_" + patient.getRole()))
            );
        }

        Doctor doctor = doctorRepository.findByEmail(email).orElse(null);
        if (doctor != null) {
            return new org.springframework.security.core.userdetails.User(
                    doctor.getEmail(),
                    doctor.getPassword(),
                    Collections.singletonList(
                            new SimpleGrantedAuthority(
                                    "ROLE_" + doctor.getRole()))
            );
        }

        throw new UsernameNotFoundException("User not found with email: " + email);
    }
}