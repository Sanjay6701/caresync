package com.healthcare.authservice.controller;

import java.util.List;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.healthcare.authservice.dto.ApiResponse;
import com.healthcare.authservice.entity.Patient;
import com.healthcare.authservice.service.PatientService;

@RestController
@RequestMapping("/api/patients")
public class PatientController {

    private final PatientService patientService;

    public PatientController(PatientService patientService) {
        this.patientService = patientService;
    }

    @PostMapping
    public ApiResponse<Patient> createPatient(
            @RequestBody Patient patient) {

        return new ApiResponse<>(
                true,
                "Patient created successfully",
                patientService.createPatient(patient),
                201
        );
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('DOCTOR','ADMIN')")
    public ApiResponse<List<Patient>> getAllPatients() {

        return new ApiResponse<>(
                true,
                "Patients fetched successfully",
                patientService.getAllPatients(),
                200
        );
    }

    @GetMapping("/{id}")
    public ApiResponse<Patient> getPatientById(
            @PathVariable Long id) {

        return new ApiResponse<>(
                true,
                "Patient fetched successfully",
                patientService.getPatientById(id),
                200
        );
    }

    @PutMapping("/{id}")
    public ApiResponse<Patient> updatePatient(
            @PathVariable Long id,
            @RequestBody Patient patient) {

        return new ApiResponse<>(
                true,
                "Patient updated successfully",
                patientService.updatePatient(id, patient),
                200
        );
    }

    @DeleteMapping("/{id}")
    public ApiResponse<Object> deletePatient(@PathVariable Long id) {

        patientService.deletePatient(id);

        return new ApiResponse<>(
                true,
                "Patient deleted successfully",
                null,
                200
        );
    }
}