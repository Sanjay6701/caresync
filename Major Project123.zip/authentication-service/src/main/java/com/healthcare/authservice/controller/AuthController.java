package com.healthcare.authservice.controller;

import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.healthcare.authservice.dto.*;
import com.healthcare.authservice.entity.*;
import com.healthcare.authservice.service.AuthService;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/register/patient")
    public ResponseEntity<ApiResponse<Patient>> registerPatient(
            @RequestBody PatientRegisterDto dto) {

        Patient patient = authService.registerPatient(dto);

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(new ApiResponse<>(
                        true,
                        "Patient registered successfully",
                        patient,
                        HttpStatus.CREATED.value()));
    }

    @PostMapping("/register/doctor")
    public ResponseEntity<ApiResponse<Doctor>> registerDoctor(
            @RequestBody DoctorRegisterDto dto) {

        Doctor doctor = authService.registerDoctor(dto);

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(new ApiResponse<>(
                        true,
                        "Doctor registered successfully",
                        doctor,
                        HttpStatus.CREATED.value()));
    }

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<LoginResponseDto>> login(
            @RequestBody LoginDto loginDto) {

        LoginResponseDto login =
                authService.login(loginDto);

        return ResponseEntity.ok(
                new ApiResponse<>(
                        true,
                        "Login successful",
                        login,
                        HttpStatus.OK.value()));
    }
}