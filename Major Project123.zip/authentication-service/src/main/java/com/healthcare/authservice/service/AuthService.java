package com.healthcare.authservice.service;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.healthcare.authservice.dto.*;
import com.healthcare.authservice.entity.Doctor;
import com.healthcare.authservice.entity.Patient;
import com.healthcare.authservice.repository.DoctorRepository;
import com.healthcare.authservice.repository.PatientRepository;
import com.healthcare.authservice.security.JwtUtil;

@Service
public class AuthService {

    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    public AuthService(PatientRepository patientRepository,
                       DoctorRepository doctorRepository,
                       PasswordEncoder passwordEncoder,
                       JwtUtil jwtUtil) {
        this.patientRepository = patientRepository;
        this.doctorRepository = doctorRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
    }

    // ✅ Register Patient
    public Patient registerPatient(PatientRegisterDto dto) {

        if (patientRepository.existsByEmail(dto.getEmail())
                || doctorRepository.existsByEmail(dto.getEmail())) {
            throw new RuntimeException(
                    "Email already registered: " + dto.getEmail());
        }

        Patient patient = new Patient();
        patient.setName(dto.getName());
        patient.setEmail(dto.getEmail());
        patient.setPassword(passwordEncoder.encode(dto.getPassword()));
        patient.setGender(dto.getGender());
        patient.setAge(dto.getAge());
        patient.setRole("PATIENT");

        return patientRepository.save(patient);
    }

    // ✅ Register Doctor
    public Doctor registerDoctor(DoctorRegisterDto dto) {

        if (doctorRepository.existsByEmail(dto.getEmail())
                || patientRepository.existsByEmail(dto.getEmail())) {
            throw new RuntimeException(
                    "Email already registered: " + dto.getEmail());
        }

        Doctor doctor = new Doctor();
        doctor.setName(dto.getName());
        doctor.setEmail(dto.getEmail());
        doctor.setPassword(passwordEncoder.encode(dto.getPassword()));
        doctor.setSpecialization(dto.getSpecialization());
        doctor.setRate(dto.getRate());
        doctor.setRole("DOCTOR");

        return doctorRepository.save(doctor);
    }

    // ✅ Login (PATIENT / DOCTOR / ADMIN)
    public LoginResponseDto login(LoginDto loginDto) {

        Patient patient = patientRepository.findByEmail(loginDto.getEmail())
                .orElse(null);

        if (patient != null) {

            if (!passwordEncoder.matches(
                    loginDto.getPassword(), patient.getPassword())) {
                throw new RuntimeException("Invalid password");
            }

            return new LoginResponseDto(
                    jwtUtil.generateTokenForPatient(patient),
                    patient.getEmail(),
                    patient.getRole()
            );
        }

        Doctor doctor = doctorRepository.findByEmail(loginDto.getEmail())
                .orElse(null);

        if (doctor != null) {

            if (!passwordEncoder.matches(
                    loginDto.getPassword(), doctor.getPassword())) {
                throw new RuntimeException("Invalid password");
            }

            String token = "ADMIN".equals(doctor.getRole())
                    ? jwtUtil.generateTokenForAdmin(doctor)
                    : jwtUtil.generateTokenForDoctor(doctor);

            return new LoginResponseDto(
                    token,
                    doctor.getEmail(),
                    doctor.getRole()
            );
        }

        throw new RuntimeException(
                "User not found with email: " + loginDto.getEmail());
    }
}