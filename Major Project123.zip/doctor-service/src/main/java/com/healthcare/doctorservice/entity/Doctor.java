package com.healthcare.doctorservice.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Doctor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    // Example: Cardiologist, General Physician
    private String specialization;

    // Example: "09:00-17:00"
    private String availableSlots;
    

    // ✅ NEW
    private int availableSlotCount = 1;

}