package com.healthcare.doctorservice.controller;

import com.healthcare.doctorservice.entity.Doctor;
import com.healthcare.doctorservice.repository.DoctorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/doctors")
@RequiredArgsConstructor
public class DoctorController {

    private final DoctorRepository repository;

    @GetMapping
    public List<Doctor> getAllDoctors() {
        return repository.findAll();
    }

    // ✅ INTERNAL: reduce slot
    @PutMapping("/{id}/slot/reduce")
    public void reduceSlot(@PathVariable Long id) {
        Doctor doctor = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Doctor not found"));

        if (doctor.getAvailableSlotCount() <= 0) {
            throw new RuntimeException("No slots available");
        }

        doctor.setAvailableSlotCount(doctor.getAvailableSlotCount() - 1);
        repository.save(doctor);
    }

    // ✅ INTERNAL: increase slot
    @PutMapping("/{id}/slot/increase")
    public void increaseSlot(@PathVariable Long id) {
        Doctor doctor = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Doctor not found"));

        doctor.setAvailableSlotCount(doctor.getAvailableSlotCount() + 1);
        repository.save(doctor);
    }
}
