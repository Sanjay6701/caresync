package com.healthcare.appointmentservice.controller;



import com.healthcare.appointmentservice.service.AppointmentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.Map;
@RestController
@RequestMapping("/appointments")
public class AppointmentController {

    private final AppointmentService service;

    public AppointmentController(AppointmentService service) {
        this.service = service;
    }

    @PostMapping("/auto-book")
    public ResponseEntity<?> autoBook(@RequestBody Map<String, Object> request) {
        try {
            return ResponseEntity.ok(service.autoBook(
                    Long.valueOf(request.get("patientId").toString()),
                    request.get("medicalProblem").toString(),
                    request.get("date").toString(),
                    request.get("preferredStart").toString(),
                    request.get("preferredEnd").toString()
            ));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", e.getMessage()));
        }
    }

    // ✅ DELETE = slot restore automatically
    @DeleteMapping("/{id}")
    public ResponseEntity<?> cancel(@PathVariable Long id) {
        service.cancelAppointment(id);
        return ResponseEntity.ok(
                Map.of("message", "Appointment cancelled and slot restored")
        );
    }

    @GetMapping("/all")
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(service.getAllAppointments());
    }
}