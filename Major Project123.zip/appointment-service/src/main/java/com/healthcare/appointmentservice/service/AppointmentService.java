package com.healthcare.appointmentservice.service;

import com.healthcare.appointmentservice.entity.Appointment;
import com.healthcare.appointmentservice.repository.AppointmentRepository;
import com.healthcare.appointmentservice.model.Doctor;
import org.springframework.stereotype.Service;

import java.time.LocalTime;
import java.util.List;
@Service
public class AppointmentService {

    private final AppointmentRepository repository;
    private final DoctorClient doctorClient;

    public AppointmentService(AppointmentRepository repository,
                              DoctorClient doctorClient) {
        this.repository = repository;
        this.doctorClient = doctorClient;
    }

    // ✅ Problem → specialization mapping
    private String mapProblemToSpecialization(String problem) {
        problem = problem.toLowerCase();

        if (problem.contains("heart")) return "Cardiologist";
        if (problem.contains("fever")) return "General Physician";
        if (problem.contains("skin")) return "Dermatologist";
        if (problem.contains("bone")) return "Orthopedic";
        if (problem.contains("neuro")) return "Neurologist";

        return "General Physician";
    }

    // ✅ Overlap check
    private boolean overlaps(String s1, String e1, String s2, String e2) {
        LocalTime start1 = LocalTime.parse(s1);
        LocalTime end1 = LocalTime.parse(e1);
        LocalTime start2 = LocalTime.parse(s2);
        LocalTime end2 = LocalTime.parse(e2);

        return start1.isBefore(end2) && end1.isAfter(start2);
    }

    // ✅ CREATE / AUTO BOOK (slot reduces automatically)
    public Appointment autoBook(Long patientId,
                                String medicalProblem,
                                String date,
                                String preferredStart,
                                String preferredEnd) {

        String specialization = mapProblemToSpecialization(medicalProblem);
        List<Doctor> doctors = doctorClient.getDoctors();

        for (Doctor doctor : doctors) {

            if (!doctor.getSpecialization().equalsIgnoreCase(specialization))
                continue;

            if (doctor.getAvailableSlotCount() <= 0)
            {
            	throw new RuntimeException("No slots available today");
            };
            String[] slots = doctor.getAvailableSlots().split("-");
            LocalTime docStart = LocalTime.parse(slots[0]);
            LocalTime docEnd = LocalTime.parse(slots[1]);

            LocalTime reqStart = LocalTime.parse(preferredStart);
            LocalTime reqEnd = LocalTime.parse(preferredEnd);

            if (reqStart.isBefore(docStart) || reqEnd.isAfter(docEnd))
                continue;

            List<Appointment> existing =
                    repository.findByDoctorIdAndDate(doctor.getId(), date);

            boolean conflict = existing.stream().anyMatch(a ->
                    overlaps(preferredStart, preferredEnd,
                             a.getStartTime(), a.getEndTime()));

            if (conflict) continue;

            // ✅ AUTOMATIC SLOT REDUCTION
            doctorClient.reduceSlot(doctor.getId());

            Appointment appt = new Appointment();
            appt.setPatientId(patientId);
            appt.setDoctorId(doctor.getId());
            appt.setDate(date);
            appt.setStartTime(preferredStart);
            appt.setEndTime(preferredEnd);
            appt.setStatus("BOOKED");

            return repository.save(appt);
        }

        throw new RuntimeException("No available doctor found");
    }

    // ✅ DELETE / CANCEL (slot increases automatically)
    public void cancelAppointment(Long appointmentId) {

        Appointment appt = repository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));

        // ✅ AUTOMATIC SLOT RESTORE
        doctorClient.increaseSlot(appt.getDoctorId());

        repository.deleteById(appointmentId);
    }

    public List<Appointment> getAllAppointments() {
        return repository.findAll();
    }
}
