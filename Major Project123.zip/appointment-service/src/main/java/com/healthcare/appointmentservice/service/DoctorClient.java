package com.healthcare.appointmentservice.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.healthcare.appointmentservice.model.Doctor;

@Component
public class DoctorClient {

    private final RestTemplate restTemplate = new RestTemplate();

    public List<Doctor> getDoctors() {
        Doctor[] doctors = restTemplate.getForObject(
                "http://localhost:8081/doctors",
                Doctor[].class
        );
        return Arrays.asList(doctors);
    }

    public void reduceSlot(Long doctorId) {
        restTemplate.put(
            "http://localhost:8081/doctors/" + doctorId + "/slot/reduce",
            null
        );
    }

    public void increaseSlot(Long doctorId) {
        restTemplate.put(
            "http://localhost:8081/doctors/" + doctorId + "/slot/increase",
            null
        );
    }
}
