package com.healthcare.appointmentservice.model;

import lombok.Data;

@Data
public class Doctor {

    private Long id;
    private String name;
    private String specialization;
    private String availableSlots; // "09:00-17:00"
    private int availableSlotCount;
}
