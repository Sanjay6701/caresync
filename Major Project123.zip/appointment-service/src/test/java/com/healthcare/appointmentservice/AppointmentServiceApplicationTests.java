package com.healthcare.appointmentservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppointmentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
