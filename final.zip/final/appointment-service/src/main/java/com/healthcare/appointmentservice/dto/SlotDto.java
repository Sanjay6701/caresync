package com.healthcare.appointmentservice.dto;

import lombok.Data;
import java.time.LocalDate;

@Data
public class SlotDto {
    private Long did;
    private LocalDate slotDate;
    private int availableSlots;
}