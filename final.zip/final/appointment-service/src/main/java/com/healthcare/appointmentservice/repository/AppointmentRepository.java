package com.healthcare.appointmentservice.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.healthcare.appointmentservice.entity.Appointment;

public interface AppointmentRepository
        extends JpaRepository<Appointment, Long> {

    // ✅ Derived operations
    List<Appointment> findByPatientId(Long patientId);

    List<Appointment> findByDoctorId(Long doctorId);
    
    List<Appointment> findByPatientIdAndBookingDateTimeBetween(
            Long patientId,
            LocalDateTime start,
            LocalDateTime end
    );
}
