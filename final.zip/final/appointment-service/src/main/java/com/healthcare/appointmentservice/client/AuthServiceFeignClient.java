package com.healthcare.appointmentservice.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import com.healthcare.appointmentservice.config.FeignClientConfig;
import com.healthcare.appointmentservice.dto.ApiResponseDto;
import com.healthcare.appointmentservice.dto.DoctorDto;
import com.healthcare.appointmentservice.dto.SlotDto;

@FeignClient(
	    name = "authentication-service",
	    configuration = FeignClientConfig.class
	)
	public interface AuthServiceFeignClient {

	    @GetMapping("/api/doctors/{id}")
	    ApiResponseDto<DoctorDto> getDoctorById(@PathVariable("id") Long id);

	    @GetMapping("/api/slots/doctor/{did}")
	    SlotDto getSlotByDoctorId(@PathVariable("did") Long did);

	    @PutMapping("/api/slots/doctor/{did}/decrement")
	    void decrementSlot(@PathVariable("did") Long did);
	    

	    // ✅ NEW – increment slot
	       @PutMapping("/api/slots/doctor/{did}/increment")
	       void incrementSlot(@PathVariable("did") Long did);

	}