package com.healthcare.appointmentservice.dto;

import lombok.Data;

@Data
public class DoctorDto {
    private Long did;
    private double rate;
}
