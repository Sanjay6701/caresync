package com.healthcare.appointmentservice.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.healthcare.appointmentservice.dto.ApiResponseDto;
import com.healthcare.appointmentservice.entity.Appointment;
import com.healthcare.appointmentservice.service.AppointmentService;

@RestController
@RequestMapping("/appointments")
public class AppointmentController {

    private final AppointmentService appointmentService;

    public AppointmentController(AppointmentService appointmentService) {
        this.appointmentService = appointmentService;
    }

    // ✅ CREATE
    @PostMapping("/book/patients/{patientId}/doctors/{doctorId}")
    public ApiResponseDto<Appointment> bookAppointment(
            @PathVariable Long patientId,
            @PathVariable Long doctorId) {

        Appointment appointment =
                appointmentService.bookAppointment(patientId, doctorId);

        return new ApiResponseDto<>(
                true,
                "Appointment booked successfully",
                appointment,
                HttpStatus.CREATED.value()
        );
    }

    // ✅ READ BY ID (Used by Prescription Service)
    @GetMapping("/{id}")
    public ApiResponseDto<Appointment> getById(@PathVariable Long id) {

        return new ApiResponseDto<>(
                true,
                "Appointment fetched successfully",
                appointmentService.getAppointmentById(id),
                HttpStatus.OK.value()
        );
    }

    // ✅ READ ALL
    @GetMapping
    public ApiResponseDto<List<Appointment>> getAll() {

        return new ApiResponseDto<>(
                true,
                "All appointments fetched",
                appointmentService.getAllAppointments(),
                HttpStatus.OK.value()
        );
    }

    // ✅ DERIVED – BY PATIENT
    @GetMapping("/patient/{patientId}")
    public ApiResponseDto<List<Appointment>> getByPatient(
            @PathVariable Long patientId) {

        return new ApiResponseDto<>(
                true,
                "Appointments fetched for patient",
                appointmentService.getByPatient(patientId),
                HttpStatus.OK.value()
        );
    }

    // ✅ DERIVED – BY DOCTOR
    @GetMapping("/doctor/{doctorId}")
    public ApiResponseDto<List<Appointment>> getByDoctor(
            @PathVariable Long doctorId) {

        return new ApiResponseDto<>(
                true,
                "Appointments fetched for doctor",
                appointmentService.getByDoctor(doctorId),
                HttpStatus.OK.value()
        );
    }

    // ✅ UPDATE
    @PutMapping("/{id}")
    public ApiResponseDto<Appointment> update(
            @PathVariable Long id,
            @RequestBody Appointment updated) {

        return new ApiResponseDto<>(
                true,
                "Appointment updated",
                appointmentService.updateAppointment(id, updated),
                HttpStatus.OK.value()
        );
    }

    // ✅ DELETE (CANCEL)
   
    @DeleteMapping("/cancel/{appointmentId}")
    public ApiResponseDto<Object> cancel(
            @PathVariable Long appointmentId) {

        appointmentService.cancelAppointment(appointmentId);

        return new ApiResponseDto<>(
                true,
                "Appointment cancelled successfully",
                null,
                HttpStatus.OK.value()
        );
    }
    
    
    @GetMapping("/patient/{patientId}/today")
    public ApiResponseDto<List<Appointment>> getTodayAppointments(
            @PathVariable Long patientId) {

        List<Appointment> appointments =
                appointmentService.getTodayAppointments(patientId);

        return new ApiResponseDto<>(
                true,
                "Today's appointments fetched successfully",
                appointments,
                HttpStatus.OK.value()
        );
    }
}
