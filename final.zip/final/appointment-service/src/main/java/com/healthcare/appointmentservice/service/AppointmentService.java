package com.healthcare.appointmentservice.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.time.LocalDate;
import java.time.LocalDateTime;


import org.springframework.stereotype.Service;

import com.healthcare.appointmentservice.client.AuthServiceFeignClient;
import com.healthcare.appointmentservice.dto.ApiResponseDto;
import com.healthcare.appointmentservice.dto.DoctorDto;
import com.healthcare.appointmentservice.dto.SlotDto;
import com.healthcare.appointmentservice.entity.Appointment;
import com.healthcare.appointmentservice.repository.AppointmentRepository;

@Service
public class AppointmentService {

    private final AppointmentRepository appointmentRepository;
    private final AuthServiceFeignClient authClient;

    public AppointmentService(AppointmentRepository appointmentRepository,
                              AuthServiceFeignClient authClient) {
        this.appointmentRepository = appointmentRepository;
        this.authClient = authClient;
    }

    // ✅ CREATE (Book Appointment)
    public Appointment bookAppointment(Long patientId, Long doctorId) {

        SlotDto slot = authClient.getSlotByDoctorId(doctorId);
        if (slot.getAvailableSlots() <= 0) {
            throw new RuntimeException("No available slots for doctor");
        }

        ApiResponseDto<DoctorDto> response =
                authClient.getDoctorById(doctorId);

        DoctorDto doctor = response.getData();

        authClient.decrementSlot(doctorId);

        Appointment appointment = new Appointment();
        appointment.setPatientId(patientId);
        appointment.setDoctorId(doctorId);
        appointment.setBookingDateTime(LocalDateTime.now());
        appointment.setPrice(doctor.getRate());

        return appointmentRepository.save(appointment);
    }

    // ✅ READ BY ID
    public Appointment getAppointmentById(Long id) {
        return appointmentRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Appointment not found with id: " + id));
    }

    // ✅ READ ALL
    public List<Appointment> getAllAppointments() {
        return appointmentRepository.findAll();
    }

    // ✅ READ BY PATIENT
    public List<Appointment> getByPatient(Long patientId) {
        return appointmentRepository.findByPatientId(patientId);
    }

    // ✅ READ BY DOCTOR
    public List<Appointment> getByDoctor(Long doctorId) {
        return appointmentRepository.findByDoctorId(doctorId);
    }

    // ✅ UPDATE (Only basic update allowed)
    public Appointment updateAppointment(Long id, Appointment updated) {

        Appointment existing = getAppointmentById(id);

        existing.setBookingDateTime(updated.getBookingDateTime());

        return appointmentRepository.save(existing);
    }

    // ✅ DELETE (Cancel Appointment)
    public void cancelAppointment(Long appointmentId) {

        Appointment appointment = getAppointmentById(appointmentId);

        authClient.incrementSlot(appointment.getDoctorId());

        appointmentRepository.delete(appointment);
    }
    
    
    public List<Appointment> getTodayAppointments(Long patientId) {

        LocalDate today = LocalDate.now();

        return appointmentRepository
                .findByPatientIdAndBookingDateTimeBetween(
                        patientId,
                        today.atStartOfDay(),
                        today.plusDays(1).atStartOfDay()
                );
    }

}