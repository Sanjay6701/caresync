package com.healthcare.prescriptionservice.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.healthcare.prescriptionservice.client.AppointmentFeignClient;
import com.healthcare.prescriptionservice.dto.ApiResponseDto;
import com.healthcare.prescriptionservice.dto.AppointmentDto;
import com.healthcare.prescriptionservice.dto.PrescriptionRequestDto;
import com.healthcare.prescriptionservice.entity.MedicineItem;
import com.healthcare.prescriptionservice.entity.Prescription;
import com.healthcare.prescriptionservice.repository.PrescriptionRepository;

@Service
public class PrescriptionService {

    private final PrescriptionRepository repository;
    private final AppointmentFeignClient appointmentClient;

    public PrescriptionService(
            PrescriptionRepository repository,
            AppointmentFeignClient appointmentClient) {
        this.repository = repository;
        this.appointmentClient = appointmentClient;
    }

    // ✅ CREATE OR UPDATE (ONE Prescription per Appointment)
    public Prescription createOrUpdatePrescription(PrescriptionRequestDto dto) {

        // 🔴 Input validation
        if (dto == null) {
            throw new IllegalArgumentException("Request body cannot be null");
        }

        if (dto.getAppointmentId() == null) {
            throw new IllegalArgumentException("Appointment ID is mandatory");
        }

        if (dto.getMedicines() == null || dto.getMedicines().isEmpty()) {
            throw new IllegalArgumentException("Medicines list cannot be empty");
        }

        // 🔴 Fetch appointment
        ApiResponseDto<AppointmentDto> response =
                appointmentClient.getAppointmentById(dto.getAppointmentId());

        if (response == null) {
            throw new IllegalStateException("No response from Appointment Service");
        }

        AppointmentDto appt = response.getData();

        if (appt == null) {
            throw new RuntimeException(
                    "Appointment not found with id: " + dto.getAppointmentId());
        }

        // 🔴 Appointment sanity checks
        if (appt.getId() == null ||
            appt.getPatientId() == null ||
            appt.getDoctorId() == null ||
            appt.getBookingDateTime() == null) {

            throw new IllegalStateException(
                    "Incomplete appointment data for id: " + dto.getAppointmentId());
        }

        // 🔴 UPSERT logic
        Prescription prescription = repository
                .findByAppointmentId(dto.getAppointmentId())
                .orElse(new Prescription());

        boolean isNew = prescription.getId() == null;

        // 🔴 Map fields
        prescription.setAppointmentId(appt.getId());
        prescription.setPatientId(appt.getPatientId());
        prescription.setDoctorId(appt.getDoctorId());
        prescription.setAppointmentDateTime(appt.getBookingDateTime());
        prescription.setDoctorNotes(dto.getDoctorNotes());
        prescription.setMedicines(dto.getMedicines());

        if (isNew) {
            prescription.setStatus("CREATED");
            prescription.setCreatedAt(LocalDateTime.now());
        } else {
            prescription.setStatus("UPDATED");
        }

        Prescription saved = repository.save(prescription);

        if (saved == null) {
            throw new IllegalStateException("Failed to save prescription");
        }

        return saved;
    }

    // ✅ READ BY ID
    public Prescription getById(Long id) {

        if (id == null) {
            throw new IllegalArgumentException("Prescription ID cannot be null");
        }

        return repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Prescription not found with id: " + id));
    }

    // ✅ READ ALL
    public List<Prescription> getAll() {
        return repository.findAll();
    }

    // ✅ READ BY PATIENT
    public List<Prescription> getByPatient(Long patientId) {

        if (patientId == null) {
            throw new IllegalArgumentException("Patient ID cannot be null");
        }

        return repository.findByPatientId(patientId);
    }

    // ✅ READ BY DOCTOR
    public List<Prescription> getByDoctor(Long doctorId) {

        if (doctorId == null) {
            throw new IllegalArgumentException("Doctor ID cannot be null");
        }

        return repository.findByDoctorId(doctorId);
    }

    // ✅ DELETE
    public void delete(Long id) {

        Prescription prescription = getById(id);
        repository.delete(prescription);
    }
    
    
    
 // ✅ READ BY APPOINTMENT ID
    public Prescription getByAppointmentId(Long appointmentId) {

        if (appointmentId == null) {
            throw new IllegalArgumentException("Appointment ID cannot be null");
        }

        return repository.findByAppointmentId(appointmentId)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Prescription not found for appointment id: " + appointmentId));
    }
    
    
 // ✅ UPDATE MEDICINES BY APPOINTMENT ID (Used by Pharma Service)
    public void updateMedicinesByAppointmentId(
            Long appointmentId,
            List<MedicineItem> medicines) {

        if (appointmentId == null) {
            throw new IllegalArgumentException("Appointment ID cannot be null");
        }

        if (medicines == null || medicines.isEmpty()) {
            throw new IllegalArgumentException("Medicines list cannot be empty");
        }

        Prescription prescription = repository.findByAppointmentId(appointmentId)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Prescription not found for appointment id: " + appointmentId));

        prescription.setMedicines(medicines);
        prescription.setStatus("UPDATED");

        repository.save(prescription);
    }

}
