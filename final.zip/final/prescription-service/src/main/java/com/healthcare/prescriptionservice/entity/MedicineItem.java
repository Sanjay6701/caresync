package com.healthcare.prescriptionservice.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MedicineItem {

    private String name;    // e.g. "Dolo 650"
    private int quantity;   // e.g. 2
}