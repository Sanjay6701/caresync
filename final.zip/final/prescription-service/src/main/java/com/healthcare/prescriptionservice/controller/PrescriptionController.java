package com.healthcare.prescriptionservice.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import com.healthcare.prescriptionservice.dto.ApiResponseDto;
import com.healthcare.prescriptionservice.dto.PrescriptionRequestDto;
import com.healthcare.prescriptionservice.entity.MedicineItem;
import com.healthcare.prescriptionservice.entity.Prescription;
import com.healthcare.prescriptionservice.service.PrescriptionService;

@RestController
@RequestMapping("/prescriptions")
public class PrescriptionController {

    private final PrescriptionService service;

    public PrescriptionController(PrescriptionService service) {
        this.service = service;
    }

    // ✅ CREATE / UPDATE (UPSERT)
    @PostMapping
    public ApiResponseDto<Prescription> createOrUpdate(
            @RequestBody PrescriptionRequestDto dto) {

        Prescription prescription =
                service.createOrUpdatePrescription(dto);

        return new ApiResponseDto<>(
                true,
                "Prescription saved successfully",
                prescription,
                HttpStatus.OK.value()
        );
    }

    // ✅ READ BY ID
    @GetMapping("/{id}")
    public ApiResponseDto<Prescription> getById(
            @PathVariable Long id) {

        return new ApiResponseDto<>(
                true,
                "Prescription fetched successfully",
                service.getById(id),
                HttpStatus.OK.value()
        );
    }

    // ✅ READ ALL
    @GetMapping
    public ApiResponseDto<List<Prescription>> getAll() {

        return new ApiResponseDto<>(
                true,
                "All prescriptions fetched successfully",
                service.getAll(),
                HttpStatus.OK.value()
        );
    }

    // ✅ READ BY PATIENT
    @GetMapping("/patient/{patientId}")
    public ApiResponseDto<List<Prescription>> getByPatient(
            @PathVariable Long patientId) {

        return new ApiResponseDto<>(
                true,
                "Prescriptions fetched for patient",
                service.getByPatient(patientId),
                HttpStatus.OK.value()
        );
    }

    // ✅ READ BY DOCTOR
    @GetMapping("/doctor/{doctorId}")
    public ApiResponseDto<List<Prescription>> getByDoctor(
            @PathVariable Long doctorId) {

        return new ApiResponseDto<>(
                true,
                "Prescriptions fetched for doctor",
                service.getByDoctor(doctorId),
                HttpStatus.OK.value()
        );
    }

    // ✅ DELETE
    @DeleteMapping("/{id}")
    public ApiResponseDto<Object> delete(
            @PathVariable Long id) {

        service.delete(id);

        return new ApiResponseDto<>(
                true,
                "Prescription deleted successfully",
                null,
                HttpStatus.OK.value()
        );
    }
    
 // ✅ READ BY APPOINTMENT ID
    @GetMapping("/appointment/{appointmentId}")
    public ApiResponseDto<Prescription> getByAppointmentId(
            @PathVariable Long appointmentId) {

        return new ApiResponseDto<>(
                true,
                "Prescription fetched successfully for appointment",
                service.getByAppointmentId(appointmentId),
                HttpStatus.OK.value()
        );
    }
    
    
 // ✅ UPDATE MEDICINES (Called by Pharma Service)
    @PutMapping("/{appointmentId}/medicines")
    public ApiResponseDto<Object> updateMedicines(
            @PathVariable Long appointmentId,
            @RequestBody List<MedicineItem> medicines) {

        service.updateMedicinesByAppointmentId(appointmentId, medicines);

        return new ApiResponseDto<>(
                true,
                "Prescription medicines updated successfully",
                null,
                HttpStatus.OK.value()
        );
    }

}
