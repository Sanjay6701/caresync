package com.healthcare.prescriptionservice.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healthcare.prescriptionservice.entity.*;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;
import java.util.List;

@Converter
public class MedicineListJsonConverter
        implements AttributeConverter<List<MedicineItem>, String> {

    private static final ObjectMapper mapper = new ObjectMapper();

    @Override
    public String convertToDatabaseColumn(List<MedicineItem> medicines) {
        try {
            return medicines == null ? "[]" : mapper.writeValueAsString(medicines);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Failed to convert medicines to JSON", e);
        }
    }

    @Override
    public List<MedicineItem> convertToEntityAttribute(String json) {
        try {
            return json == null || json.isEmpty()
                    ? List.of()
                    : mapper.readValue(json, new TypeReference<>() {});
        } catch (Exception e) {
            throw new RuntimeException("Failed to convert JSON to medicines", e);
        }
    }
}
