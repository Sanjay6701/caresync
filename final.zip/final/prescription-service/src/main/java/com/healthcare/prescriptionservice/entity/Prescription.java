package com.healthcare.prescriptionservice.entity;

import java.time.LocalDateTime;
import java.util.List;

import com.healthcare.prescriptionservice.entity.*;
import com.healthcare.prescriptionservice.util.MedicineListJsonConverter;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "prescriptions")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Prescription {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private Long appointmentId;

    private Long patientId;
    private Long doctorId;

    private LocalDateTime appointmentDateTime;

    @Column(length = 1000)
    private String doctorNotes;

    // ✅ Medicine + quantity as JSON
    @Convert(converter = MedicineListJsonConverter.class)
    @Column(length = 4000)
    private List<MedicineItem> medicines;

    private String status;        // CREATED / UPDATED
    private LocalDateTime createdAt;
}