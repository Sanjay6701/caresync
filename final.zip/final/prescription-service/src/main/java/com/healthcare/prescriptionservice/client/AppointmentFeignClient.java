package com.healthcare.prescriptionservice.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.healthcare.prescriptionservice.config.FeignRequestInterceptorConfig;
import com.healthcare.prescriptionservice.dto.ApiResponseDto;
//import com.healthcare.prescriptionservice.config.FeignClientConfig;
import com.healthcare.prescriptionservice.dto.AppointmentDto;

@FeignClient(name = "appointment-service",configuration = FeignRequestInterceptorConfig.class)
public interface AppointmentFeignClient {

    @GetMapping("/appointments/{appointmentId}")
    ApiResponseDto<AppointmentDto> getAppointmentById(
            @PathVariable Long appointmentId);
}
