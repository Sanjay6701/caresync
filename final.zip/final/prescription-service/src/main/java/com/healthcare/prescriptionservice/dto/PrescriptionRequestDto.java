package com.healthcare.prescriptionservice.dto;

import java.util.List;

import com.healthcare.prescriptionservice.entity.MedicineItem;
import lombok.Data;

@Data
public class PrescriptionRequestDto {

    private Long appointmentId;
    private String doctorNotes;
    private List<MedicineItem> medicines;
}