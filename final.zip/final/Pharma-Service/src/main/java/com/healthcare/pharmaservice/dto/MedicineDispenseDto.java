package com.healthcare.pharmaservice.dto;

import lombok.Data;

@Data
public class MedicineDispenseDto {

    private String name;
    private int quantity;
}