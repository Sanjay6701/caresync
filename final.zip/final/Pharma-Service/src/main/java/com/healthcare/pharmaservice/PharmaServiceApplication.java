package com.healthcare.pharmaservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
public class PharmaServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(PharmaServiceApplication.class, args);
    }
}