package com.healthcare.pharmaservice.dto;
import lombok.Data;

@Data
public class MedicineRequestDto {

    private String name;
    private String disease;
    private int stockQuantity;
    private double pricePerUnit;
}


