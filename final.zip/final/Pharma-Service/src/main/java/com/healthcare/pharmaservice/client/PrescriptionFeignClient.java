package com.healthcare.pharmaservice.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import com.healthcare.pharmaservice.dto.ApiResponseDto;
import com.healthcare.pharmaservice.dto.MedicineDispenseDto;

import java.util.List;

@FeignClient(name = "prescription-service")
public interface PrescriptionFeignClient {

    @PutMapping("/prescriptions/{appointmentId}/medicines")
    ApiResponseDto<Object> updateMedicines(
            @PathVariable Long appointmentId,
            @RequestBody List<MedicineDispenseDto> medicines);
}
