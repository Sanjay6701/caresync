package com.healthcare.pharmaservice.service;

import java.util.*;

import org.springframework.stereotype.Service;

import com.healthcare.pharmaservice.client.PrescriptionFeignClient;
import com.healthcare.pharmaservice.dto.MedicineDispenseDto;
import com.healthcare.pharmaservice.dto.MedicineRequestDto;
import com.healthcare.pharmaservice.entity.Medicine;
import com.healthcare.pharmaservice.repository.MedicineRepository;

@Service
public class PharmaService {

    private final MedicineRepository repository;
    private final PrescriptionFeignClient prescriptionClient;

    public PharmaService(
            MedicineRepository repository,
            PrescriptionFeignClient prescriptionClient) {
        this.repository = repository;
        this.prescriptionClient = prescriptionClient;
    }

    // ✅ CREATE
    public Medicine addMedicine(MedicineRequestDto dto) {

        if (dto == null)
            throw new IllegalArgumentException("Medicine request cannot be null");

        if (dto.getName() == null || dto.getName().isBlank())
            throw new IllegalArgumentException("Medicine name is required");

        if (dto.getDisease() == null || dto.getDisease().isBlank())
            throw new IllegalArgumentException("Disease name is required");

        if (dto.getStockQuantity() < 0)
            throw new IllegalArgumentException("Stock quantity cannot be negative");

        repository.findByName(dto.getName()).ifPresent(m -> {
            throw new RuntimeException("Medicine already exists: " + dto.getName());
        });

        Medicine medicine = new Medicine(
                null,
                dto.getName(),
                dto.getDisease(),
                dto.getStockQuantity(),
                dto.getPricePerUnit()
        );

        return repository.save(medicine);
    }

    // ✅ READ BY ID
    public Medicine getById(Long id) {
        if (id == null)
            throw new IllegalArgumentException("Medicine ID cannot be null");

        return repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Medicine not found with id: " + id));
    }

    // ✅ READ ALL
    public List<Medicine> getAll() {
        return repository.findAll();
    }

    // ✅ UPDATE
    public Medicine update(Long id, MedicineRequestDto dto) {

        Medicine medicine = getById(id);

        if (dto.getStockQuantity() < 0)
            throw new IllegalArgumentException("Stock quantity cannot be negative");

        medicine.setDisease(dto.getDisease());
        medicine.setStockQuantity(dto.getStockQuantity());
        medicine.setPricePerUnit(dto.getPricePerUnit());

        return repository.save(medicine);
    }

    // ✅ DELETE
    public void delete(Long id) {
        repository.delete(getById(id));
    }

    // ✅ DISPENSE MEDICINES (CORE LOGIC)
    public List<MedicineDispenseDto> dispenseMedicines(
            Long appointmentId, List<MedicineDispenseDto> requested) {

        if (appointmentId == null)
            throw new IllegalArgumentException("Appointment ID is required");

        if (requested == null || requested.isEmpty())
            throw new IllegalArgumentException("No medicines requested");

        List<MedicineDispenseDto> finalList = new ArrayList<>();

        for (MedicineDispenseDto req : requested) {

            Medicine medicine = repository.findByName(req.getName()).orElse(null);

            if (medicine != null &&
                medicine.getStockQuantity() >= req.getQuantity()) {

                medicine.setStockQuantity(
                        medicine.getStockQuantity() - req.getQuantity());
                repository.save(medicine);
                finalList.add(req);
            } else {

                if (medicine == null)
                    throw new RuntimeException(
                            "Medicine not found: " + req.getName());

                List<Medicine> alternatives =
                        repository.findByDiseaseOrderByStockQuantityDesc(
                                medicine.getDisease());

                Medicine substitute = alternatives.stream()
                        .filter(m -> m.getStockQuantity() >= req.getQuantity())
                        .findFirst()
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "No alternative medicine available for disease: "
                                                + medicine.getDisease()));

                substitute.setStockQuantity(
                        substitute.getStockQuantity() - req.getQuantity());
                repository.save(substitute);

                MedicineDispenseDto replaced = new MedicineDispenseDto();
                replaced.setName(substitute.getName());
                replaced.setQuantity(req.getQuantity());
                finalList.add(replaced);
            }
        }

        // ✅ Update Prescription with actual medicines dispensed
        prescriptionClient.updateMedicines(appointmentId, finalList);

        return finalList;
    }
}