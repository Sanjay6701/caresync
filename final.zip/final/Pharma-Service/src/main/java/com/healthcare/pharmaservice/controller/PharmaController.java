package com.healthcare.pharmaservice.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import com.healthcare.pharmaservice.dto.ApiResponseDto;
import com.healthcare.pharmaservice.dto.MedicineDispenseDto;
import com.healthcare.pharmaservice.dto.MedicineRequestDto;
import com.healthcare.pharmaservice.entity.Medicine;
import com.healthcare.pharmaservice.service.PharmaService;

@RestController
@RequestMapping("/pharma")
public class PharmaController {

    private final PharmaService service;

    public PharmaController(PharmaService service) {
        this.service = service;
    }

    // ✅ CREATE MEDICINE
    @PostMapping("/medicines")
    public ApiResponseDto<Medicine> addMedicine(
            @RequestBody MedicineRequestDto dto) {

        Medicine medicine = service.addMedicine(dto);

        return new ApiResponseDto<>(
                true,
                "Medicine added successfully",
                medicine,
                HttpStatus.CREATED.value()
        );
    }

    // ✅ READ ALL MEDICINES
    @GetMapping("/medicines")
    public ApiResponseDto<List<Medicine>> getAllMedicines() {

        return new ApiResponseDto<>(
                true,
                "All medicines fetched successfully",
                service.getAll(),
                HttpStatus.OK.value()
        );
    }

    // ✅ READ MEDICINE BY ID
    @GetMapping("/medicines/{id}")
    public ApiResponseDto<Medicine> getMedicineById(
            @PathVariable Long id) {

        return new ApiResponseDto<>(
                true,
                "Medicine fetched successfully",
                service.getById(id),
                HttpStatus.OK.value()
        );
    }

    // ✅ UPDATE MEDICINE
    @PutMapping("/medicines/{id}")
    public ApiResponseDto<Medicine> updateMedicine(
            @PathVariable Long id,
            @RequestBody MedicineRequestDto dto) {

        Medicine medicine = service.update(id, dto);

        return new ApiResponseDto<>(
                true,
                "Medicine updated successfully",
                medicine,
                HttpStatus.OK.value()
        );
    }

    // ✅ DELETE MEDICINE
    @DeleteMapping("/medicines/{id}")
    public ApiResponseDto<Object> deleteMedicine(
            @PathVariable Long id) {

        service.delete(id);

        return new ApiResponseDto<>(
                true,
                "Medicine deleted successfully",
                null,
                HttpStatus.OK.value()
        );
    }

    // ✅ DISPENSE MEDICINES FOR PRESCRIPTION
    @PostMapping("/dispense/{appointmentId}")
    public ApiResponseDto<List<MedicineDispenseDto>> dispenseMedicines(
            @PathVariable Long appointmentId,
            @RequestBody List<MedicineDispenseDto> medicines) {

        List<MedicineDispenseDto> dispensed =
                service.dispenseMedicines(appointmentId, medicines);

        return new ApiResponseDto<>(
                true,
                "Medicines dispensed successfully",
                dispensed,
                HttpStatus.OK.value()
        );
    }
}
