package com.healthcare.pharmaservice.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.healthcare.pharmaservice.entity.Medicine;

public interface MedicineRepository extends JpaRepository<Medicine, Long> {

    Optional<Medicine> findByName(String name);

    List<Medicine> findByDisease(String disease);

    List<Medicine> findByDiseaseOrderByStockQuantityDesc(String disease);
}