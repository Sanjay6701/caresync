package com.healthcare.authservice.service;

import java.time.LocalDate;

import org.springframework.stereotype.Service;

import com.healthcare.authservice.entity.Slot;
import com.healthcare.authservice.repository.SlotRepository;

@Service
public class SlotService {

    private static final int DAILY_SLOT_LIMIT = 10;

    private final SlotRepository slotRepository;

    public SlotService(SlotRepository slotRepository) {
        this.slotRepository = slotRepository;
    }

    // ✅ Validate & reset slot on doctor login
    public Slot validateAndResetSlot(Long doctorId) {

        LocalDate today = LocalDate.now();

        Slot slot = slotRepository.findByDid(doctorId).orElse(null);

        if (slot == null) {
            Slot newSlot = new Slot();
            newSlot.setDid(doctorId);
            newSlot.setSlotDate(today);
            newSlot.setAvailableSlots(DAILY_SLOT_LIMIT);
            return slotRepository.save(newSlot);
        }

        if (slot.getSlotDate().isBefore(today)) {
            slot.setSlotDate(today);
            slot.setAvailableSlots(DAILY_SLOT_LIMIT);
            return slotRepository.save(slot);
        }

        return slot;
    }

    // ✅ Get slot by slot ID
    public Slot getSlotById(Long slotId) {
        return slotRepository.findById(slotId)
                .orElseThrow(() ->
                        new RuntimeException("Slot not found with id: " + slotId));
    }

    // ✅ Get slot by Doctor ID (did)
    public Slot getSlotByDoctorId(Long doctorId) {
        return slotRepository.findByDid(doctorId)
                .orElseThrow(() ->
                        new RuntimeException("Slot not found for doctor id: " + doctorId));
    }

    // ✅ Update available slots manually
    public Slot updateAvailableSlots(Long doctorId, int slots) {

        if (slots < 0) {
            throw new RuntimeException("Available slots cannot be negative");
        }

        Slot slot = slotRepository.findByDid(doctorId)
                .orElseThrow(() ->
                        new RuntimeException("Slot not found for doctor id: " + doctorId));

        slot.setAvailableSlots(slots);
        return slotRepository.save(slot);
    }

    // ✅ Reduce slot after booking
    public Slot decrementSlot(Long doctorId) {

        Slot slot = slotRepository.findByDid(doctorId)
                .orElseThrow(() ->
                        new RuntimeException("Slot not found for doctor id: " + doctorId));

        if (slot.getAvailableSlots() <= 0) {
            throw new RuntimeException("No slots available");
        }

        slot.setAvailableSlots(slot.getAvailableSlots() - 1);
        return slotRepository.save(slot);
    }
    
    
 // ✅ Increase slot after appointment cancellation
    public Slot incrementSlot(Long doctorId) {

        Slot slot = slotRepository.findByDid(doctorId)
                .orElseThrow(() ->
                        new RuntimeException("Slot not found for doctor id: " + doctorId));

        slot.setAvailableSlots(slot.getAvailableSlots() + 1);
        return slotRepository.save(slot);
    }

}