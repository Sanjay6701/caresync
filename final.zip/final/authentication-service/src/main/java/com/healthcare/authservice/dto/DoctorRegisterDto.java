package com.healthcare.authservice.dto;

import lombok.Data;

@Data
public class DoctorRegisterDto {

    private String name;
    private String email;
    private String password;
    private String specialization;
    private double rate;
    
}