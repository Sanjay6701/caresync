package com.healthcare.authservice.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.healthcare.authservice.entity.Slot;

public interface SlotRepository extends JpaRepository<Slot, Long> {

    Optional<Slot> findByDid(Long did);
}
