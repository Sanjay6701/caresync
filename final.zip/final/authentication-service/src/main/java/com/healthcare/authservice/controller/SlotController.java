package com.healthcare.authservice.controller;

import org.springframework.web.bind.annotation.*;

import com.healthcare.authservice.entity.Slot;
import com.healthcare.authservice.service.SlotService;

@RestController
@RequestMapping("/api/slots")
public class SlotController {

    private final SlotService slotService;

    public SlotController(SlotService slotService) {
        this.slotService = slotService;
    }

    // ✅ Get slot by slot ID
    @GetMapping("/{id}")
    public Slot getSlotById(@PathVariable Long id) {
        return slotService.getSlotById(id);
    }

    // ✅ Get slot by Doctor ID
    @GetMapping("/doctor/{did}")
    public Slot getSlotByDoctorId(@PathVariable Long did) {
        return slotService.getSlotByDoctorId(did);
    }

    // ✅ Update available slots manually
    @PutMapping("/doctor/{did}/update/{slots}")
    public Slot updateAvailableSlots(
            @PathVariable Long did,
            @PathVariable int slots) {
        return slotService.updateAvailableSlots(did, slots);
    }

    // ✅ Decrement slot after appointment booking
    @PutMapping("/doctor/{did}/decrement")
    public Slot decrementSlot(@PathVariable Long did) {
        return slotService.decrementSlot(did);
    }
    
    
 // ✅ Increment slot after appointment cancellation
    @PutMapping("/doctor/{did}/increment")
    public Slot incrementSlot(@PathVariable Long did) {
        return slotService.incrementSlot(did);
    }
}