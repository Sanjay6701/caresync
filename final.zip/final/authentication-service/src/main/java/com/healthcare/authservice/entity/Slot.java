package com.healthcare.authservice.entity;

import java.time.LocalDate;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Slot {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private Long did;

    @Column(nullable = false)
    private LocalDate slotDate;

    @Column(nullable = false)
    private int availableSlots;
}